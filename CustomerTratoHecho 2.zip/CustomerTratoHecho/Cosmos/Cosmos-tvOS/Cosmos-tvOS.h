//
//  Cosmos-tvOS.h
//  Cosmos-tvOS
//
//  Created by Evgenii on 24/11/2015.
//  Copyright © 2015 Marketplacer. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Cosmos-tvOS.
FOUNDATION_EXPORT double Cosmos_tvOSVersionNumber;

//! Project version string for Cosmos-tvOS.
FOUNDATION_EXPORT const unsigned char Cosmos_tvOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Cosmos_tvOS/PublicHeader.h>


